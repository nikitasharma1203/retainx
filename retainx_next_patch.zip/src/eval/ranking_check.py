"""Does Wilson / Bayesian scoring keep new products out of the top-k and the list steadier?

For each month-start cutoff it ranks products by naive repeat rate, Wilson lower bound and a
Bayesian-shrunk rate, using only information available before that cutoff. It reports, per method:
  new_in_topk       products first sold in the last 30 days that reach the top-k (lower = steadier)
  min_buyers_topk   buyers of the least-evidenced product in the top-k (higher = better supported)
  overlap_prev      share of top-k kept from the previous month (higher = steadier)

Usage: python -m src.eval.ranking_check [--k 20] [--start 2010-07-01] [--end 2011-11-01]
"""
from __future__ import annotations

import argparse
from pathlib import Path

import pandas as pd
from sqlalchemy import create_engine

from src import config, ranking

METHODS = ["naive", "wilson", "bayes"]


def evaluate(pc: pd.DataFrame, products: pd.DataFrame, cutoffs, k: int = 20) -> pd.DataFrame:
    rows, prev = [], {}
    for c in cutoffs:
        st = ranking.product_stats(pc, products, c)
        for m in METHODS:
            top = st.sort_values([m, "n_customers"], ascending=False).head(k)
            ids = set(top.index)
            rows.append({
                "cutoff": str(pd.Timestamp(c).date()), "method": m,
                "new_in_topk": int(top["is_new"].sum()),
                "min_buyers_topk": int(top["n_customers"].min()),
                "overlap_prev": len(ids & prev[m]) / k if m in prev else float("nan"),
            })
            prev[m] = ids
    return pd.DataFrame(rows)


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--k", type=int, default=20)
    ap.add_argument("--start", default="2010-07-01")
    ap.add_argument("--end", default="2011-11-01")
    a = ap.parse_args()
    eng = create_engine(config.DB_URL)
    pc = pd.read_sql(f"select * from {config.PRODUCT_CUSTOMER_TABLE}", eng,
                     parse_dates=["first_purchase_ts", "second_purchase_ts"])
    pr = pd.read_sql(f"select stock_code, first_sale_ts from {config.PRODUCT_TABLE}", eng,
                     parse_dates=["first_sale_ts"])
    res = evaluate(pc, pr, pd.date_range(a.start, a.end, freq="MS"), a.k)
    Path("reports").mkdir(exist_ok=True)
    res.to_csv("reports/ranking_check.csv", index=False)
    print(res.groupby("method")[["new_in_topk", "min_buyers_topk", "overlap_prev"]].mean().round(2).to_string())
