# Personas (behavioural, k = 3, cutoff 2011-12-01)

Built with `python -m src.personas --cutoff 2011-12-01 --k 3` on 5,824 customers. In the first run (k searched from 3 to 7),
silhouette was 0.338 for k = 3, 0.279 for k = 4 and 0.247 for k = 7, so the structure is moderate, not sharp.
The search range now starts at 2, so a plain run may pick k = 2; use `--k 3` to reproduce these cards.
These describe **behaviour only**. The dataset has no demographics, ages or motives, and none are implied.
Figures are medians per segment. The actions are suggestions, not tested interventions.

| Persona | Customers | Share of revenue | Last order | Orders | Spend | Avg order |
|---|---|---|---|---|---|---|
| Core high-value | 2,232 (38%) | 87% | 36 days ago | 8 | £2,910 | £343 |
| New, lighter buyers | 1,753 (30%) | 7% | 49 days ago | 2 | £509 | £253 |
| Lapsed, mostly single-order | 1,839 (32%) | 5% | 425 days ago | 1 | £350 | £209 |

## Core high-value
**Who:** the 38% of customers who generate 87% of revenue. They order often (median 8 orders), have been customers for a median 647 days, and bought recently.
**Need:** continuity. Losing one of these costs far more than losing a customer from the other two groups.
**Action:** put them first on the health score. Any customer who drops to Amber or Red gets a human follow-up, not a bulk email.

## New, lighter buyers
**Who:** 30% of customers, 7% of revenue. Median 2 orders and 174 days since their first order, and still buying recently.
**Need:** a reason to place a third order. The core group's median is 8.
**Action:** a post-order campaign aimed at the second-to-third order, with a holdout group so the effect can be measured.

## Lapsed, mostly single-order
**Who:** 32% of customers, 5% of revenue. Median last order 425 days ago, typically one order.
**Need:** probably nothing worth much effort. They carry the least value.
**Action:** at most a cheap, automated win-back message, tested against a holdout. Do not spend CRM time here.

## Limits
- The three segments resemble classic recency / frequency / value groups. They are useful but coarse.
- k = 3 had the best silhouette among the values first tried (3 to 7). Silhouette tends to favour few clusters. Run `--k 4` or `--k 5` to split the core group if finer actions are needed.
- Medians of different columns need not describe a single real customer.
- Lapsed customers (over 180 days) are included here but excluded from the health score.
