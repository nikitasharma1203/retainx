import numpy as np
import pandas as pd
import pytest

from src import pricing as pr


def simulate(true_eps=-1.4, P=80, W=90, price_follows_demand=0.0, seed=0):
    rng = np.random.default_rng(seed)
    a, g = rng.normal(3, 1, P), rng.normal(0, 0.4, W)
    b, h = rng.normal(1, 0.5, P), rng.normal(0, 0.2, W)
    rows = []
    for p in range(P):
        for w in range(W):
            u = rng.normal(0, 0.3)                               # demand shock
            lp = b[p] + h[w] + rng.normal(0, 0.15) + price_follows_demand * u
            ly = a[p] + g[w] + true_eps * lp + u
            rows.append({"stock_code": f"P{p}", "week": pd.Timestamp("2010-01-04") + pd.Timedelta(weeks=w),
                         "units": float(np.exp(ly)), "price_median": float(np.exp(lp)), "price_mean": float(np.exp(lp))})
    return pd.DataFrame(rows)


def test_recovers_a_known_elasticity_when_prices_are_exogenous():
    est = pr.estimate_elasticity(simulate(-1.4))
    assert est["elasticity"] == pytest.approx(-1.4, abs=0.15)
    assert est["ci_low"] < -1.4 < est["ci_high"] and est["se"] > 0


def test_estimate_is_biased_toward_zero_when_prices_follow_demand():
    est = pr.estimate_elasticity(simulate(-1.4, price_follows_demand=0.8))
    assert est["elasticity"] > -1.4 + 0.2      # the documented weakness of observational prices


def test_twoway_demean_removes_group_means():
    rng = np.random.default_rng(1)
    a, b = rng.integers(0, 5, 300), rng.integers(0, 7, 300)
    out = pr.twoway_demean(rng.normal(size=300) + a, a, b)
    assert abs(pd.Series(out).groupby(a).mean()).max() < 1e-6 and abs(pd.Series(out).groupby(b).mean()).max() < 1e-6


def test_revenue_effect_formula():
    assert pr.revenue_effect(-1.0, 0.10) == pytest.approx(0.0)
    assert pr.revenue_effect(-2.0, 0.10) == pytest.approx(1 / 1.1 - 1)
    assert pr.revenue_effect(-0.5, 0.10) > 0


def test_seasonal_baseline_beats_naive_on_seasonal_demand():
    weeks = 160
    base = 100 + 80 * np.sin(2 * np.pi * np.arange(weeks) / 52)
    rng = np.random.default_rng(2)
    Y = pd.DataFrame({f"p{i}": np.maximum(0, base * (1 + 0.2 * i / 10) + rng.normal(0, 5, weeks)) for i in range(10)},
                     index=pd.date_range("2010-01-04", periods=weeks, freq="7D"))
    bt = pr.backtest_baselines(Y).set_index("model")["wape"]
    assert bt["same week last year"] < bt["naive (last week)"]
    with pytest.raises(ValueError):
        pr.backtest_baselines(Y.iloc[:60])
